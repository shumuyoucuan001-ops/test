import { Module } from '@nestjs/common';
import { AclController } from './acl.controller';
import { AclService } from './acl.service';
import { PrismaModule } from '../prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [AclController],
  providers: [AclService],
})
export class AclModule {}


