import { BadRequestException, Injectable } from '@nestjs/common';
import { randomBytes } from 'crypto';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AclService {
  constructor(private prisma: PrismaService) {}

  async initSchema() {
    // 在系统库创建所需表（若不存在）
    await this.prisma.$executeRawUnsafe(`
      CREATE TABLE IF NOT EXISTS sm_xitongkaifa.sys_users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(64) UNIQUE NOT NULL,
        password VARCHAR(128),
        display_name VARCHAR(64),
        code VARCHAR(64),
        session_token VARCHAR(128),
        last_login_time DATETIME,
        last_login_device VARCHAR(255),
        status TINYINT DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    // 若已有历史表且 code 为 NOT NULL，则放宽为可空
    try { await this.prisma.$executeRawUnsafe(`ALTER TABLE sm_xitongkaifa.sys_users MODIFY code VARCHAR(64) NULL`); } catch {}
    // 兼容历史表缺少列/索引：通过 information_schema 判断
    const hasCol = async (name: string) => {
      const rows: any[] = await this.prisma.$queryRawUnsafe(
        `SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='sm_xitongkaifa' AND TABLE_NAME='sys_users' AND COLUMN_NAME=? LIMIT 1`,
        name
      );
      return rows.length > 0;
    };
    if (!(await hasCol('password'))) {
      try { await this.prisma.$executeRawUnsafe(`ALTER TABLE sm_xitongkaifa.sys_users ADD COLUMN password VARCHAR(128) NULL AFTER username`); } catch {}
    }
    if (!(await hasCol('display_name'))) {
      try { await this.prisma.$executeRawUnsafe(`ALTER TABLE sm_xitongkaifa.sys_users ADD COLUMN display_name VARCHAR(64) NULL`); } catch {}
    }
    if (!(await hasCol('status'))) {
      try { await this.prisma.$executeRawUnsafe(`ALTER TABLE sm_xitongkaifa.sys_users ADD COLUMN status TINYINT NULL DEFAULT 1`); } catch {}
    }
    await this.prisma.$executeRawUnsafe(`
      CREATE TABLE IF NOT EXISTS sm_xitongkaifa.sys_roles (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(64) UNIQUE NOT NULL,
        remark VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    await this.prisma.$executeRawUnsafe(`
      CREATE TABLE IF NOT EXISTS sm_xitongkaifa.sys_permissions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        code VARCHAR(128) UNIQUE NOT NULL,
        name VARCHAR(128) NOT NULL,
        path VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    await this.prisma.$executeRawUnsafe(`
      CREATE TABLE IF NOT EXISTS sm_xitongkaifa.sys_user_roles (
        user_id INT NOT NULL,
        role_id INT NOT NULL,
        PRIMARY KEY(user_id, role_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    await this.prisma.$executeRawUnsafe(`
      CREATE TABLE IF NOT EXISTS sm_xitongkaifa.sys_role_permissions (
        role_id INT NOT NULL,
        permission_id INT NOT NULL,
        PRIMARY KEY(role_id, permission_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
  }

  private async ensureSysUsersSchema() {
    // 动态校验并补齐列
    const hasCol = async (name: string) => {
      const rows: any[] = await this.prisma.$queryRawUnsafe(
        `SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='sm_xitongkaifa' AND TABLE_NAME='sys_users' AND COLUMN_NAME=? LIMIT 1`,
        name
      );
      return rows.length > 0;
    };
    if (!(await hasCol('password'))) {
      try { await this.prisma.$executeRawUnsafe(`ALTER TABLE sm_xitongkaifa.sys_users ADD COLUMN password VARCHAR(128) NULL AFTER username`); } catch {}
    }
    if (!(await hasCol('display_name'))) {
      try { await this.prisma.$executeRawUnsafe(`ALTER TABLE sm_xitongkaifa.sys_users ADD COLUMN display_name VARCHAR(64) NULL`); } catch {}
    }
    if (!(await hasCol('status'))) {
      try { await this.prisma.$executeRawUnsafe(`ALTER TABLE sm_xitongkaifa.sys_users ADD COLUMN status TINYINT NULL DEFAULT 1`); } catch {}
    }
    if (!(await hasCol('code'))) {
      try { await this.prisma.$executeRawUnsafe(`ALTER TABLE sm_xitongkaifa.sys_users ADD COLUMN code VARCHAR(64) NULL`); } catch {}
    }
    if (!(await hasCol('session_token'))) {
      try { await this.prisma.$executeRawUnsafe(`ALTER TABLE sm_xitongkaifa.sys_users ADD COLUMN session_token VARCHAR(128) NULL`); } catch {}
    }
    if (!(await hasCol('last_login_time'))) {
      try { await this.prisma.$executeRawUnsafe(`ALTER TABLE sm_xitongkaifa.sys_users ADD COLUMN last_login_time DATETIME NULL`); } catch {}
    }
    if (!(await hasCol('last_login_device'))) {
      try { await this.prisma.$executeRawUnsafe(`ALTER TABLE sm_xitongkaifa.sys_users ADD COLUMN last_login_device VARCHAR(255) NULL`); } catch {}
    }
    // 放宽 code 可空
    try { await this.prisma.$executeRawUnsafe(`ALTER TABLE sm_xitongkaifa.sys_users MODIFY code VARCHAR(64) NULL`); } catch {}
  }

  // 权限CRUD
  listPermissions() {
    return this.prisma.$queryRawUnsafe(`SELECT * FROM sm_xitongkaifa.sys_permissions ORDER BY id DESC`);
  }
  createPermission(p: { code: string; name: string; path: string }) {
    return this.prisma.$executeRawUnsafe(
      `INSERT INTO sm_xitongkaifa.sys_permissions(code,name,path) VALUES(?,?,?)`,
      p.code,
      p.name,
      p.path,
    );
  }
  updatePermission(id: number, p: { code?: string; name?: string; path?: string }) {
    const sets: string[] = [];
    const vals: any[] = [];
    if (p.code !== undefined) { sets.push('code=?'); vals.push(p.code); }
    if (p.name !== undefined) { sets.push('name=?'); vals.push(p.name); }
    if (p.path !== undefined) { sets.push('path=?'); vals.push(p.path); }
    if (!sets.length) return Promise.resolve(0);
    vals.push(id);
    return this.prisma.$executeRawUnsafe(`UPDATE sm_xitongkaifa.sys_permissions SET ${sets.join(',')} WHERE id=?`, ...vals);
  }
  deletePermission(id: number) {
    return this.prisma.$executeRawUnsafe(`DELETE FROM sm_xitongkaifa.sys_permissions WHERE id=?`, id);
  }

  // 角色与授权
  listRoles() {
    return this.prisma.$queryRawUnsafe(`SELECT * FROM sm_xitongkaifa.sys_roles ORDER BY id DESC`);
  }
  createRole(r: { name: string; remark?: string }) {
    return this.prisma.$executeRawUnsafe(`INSERT INTO sm_xitongkaifa.sys_roles(name,remark) VALUES(?,?)`, r.name, r.remark || null);
  }
  updateRole(id: number, r: { name?: string; remark?: string }) {
    const sets: string[] = []; const vals: any[] = [];
    if (r.name !== undefined) { sets.push('name=?'); vals.push(r.name); }
    if (r.remark !== undefined) { sets.push('remark=?'); vals.push(r.remark); }
    if (!sets.length) return Promise.resolve(0);
    vals.push(id);
    return this.prisma.$executeRawUnsafe(`UPDATE sm_xitongkaifa.sys_roles SET ${sets.join(',')} WHERE id=?`, ...vals);
  }
  deleteRole(id: number) { return this.prisma.$executeRawUnsafe(`DELETE FROM sm_xitongkaifa.sys_roles WHERE id=?`, id); }

  setRolePermissions(roleId: number, permissionIds: number[]) {
    return this.prisma.$transaction([
      this.prisma.$executeRawUnsafe(`DELETE FROM sm_xitongkaifa.sys_role_permissions WHERE role_id=?`, roleId),
      this.prisma.$executeRawUnsafe(
        `INSERT INTO sm_xitongkaifa.sys_role_permissions(role_id,permission_id) VALUES ${permissionIds.map(()=>'(?,?)').join(',')}`,
        ...permissionIds.flatMap(pid => [roleId, pid])
      )
    ]);
  }

  async getRolePermissionIds(roleId: number) {
    const rows: any[] = await this.prisma.$queryRawUnsafe(`SELECT permission_id FROM sm_xitongkaifa.sys_role_permissions WHERE role_id=?`, roleId);
    return rows.map(r => Number(r.permission_id));
  }

  // 账号管理
  async listUsers(q = '') { 
    let users: any[];
    if (!q) {
      users = await this.prisma.$queryRawUnsafe(`SELECT * FROM sm_xitongkaifa.sys_users ORDER BY id DESC`);
    } else {
      const like = `%${q}%`;
      users = await this.prisma.$queryRawUnsafe(`SELECT * FROM sm_xitongkaifa.sys_users WHERE username LIKE ? OR display_name LIKE ? ORDER BY id DESC`, like, like);
    }
    
    // 为每个用户获取角色信息
    for (const user of users) {
      const roleRows: any[] = await this.prisma.$queryRawUnsafe(`
        SELECT r.id, r.name 
        FROM sm_xitongkaifa.sys_roles r
        JOIN sm_xitongkaifa.sys_user_roles ur ON ur.role_id = r.id
        WHERE ur.user_id = ?
      `, user.id);
      user.roles = roleRows;
    }
    
    return users;
  }
  async createUser(u: { username: string; password: string; display_name: string; code?: string; status?: number }) {
    await this.ensureSysUsersSchema();
    const username = (u.username || '').trim();
    const password = (u.password || '').trim();
    const displayName = (u.display_name || '').trim();
    const code = (u.code || '').trim();
    const status = u.status ?? 1;

    if (username.length < 3 || username.length > 64) throw new BadRequestException('用户名长度需 3-64 个字符');
    if (password.length < 6 || password.length > 128) throw new BadRequestException('密码长度需 6-128 个字符');
    if (displayName.length < 1 || displayName.length > 64) throw new BadRequestException('显示名长度需 1-64 个字符');
    if (code && code.length > 64) throw new BadRequestException('编码长度不能超过 64 个字符');
    if (![0,1].includes(Number(status))) throw new BadRequestException('状态仅支持 0 或 1');

    const exists: any[] = await this.prisma.$queryRawUnsafe(`SELECT id FROM sm_xitongkaifa.sys_users WHERE username=? LIMIT 1`, username);
    if (exists.length) throw new BadRequestException('用户名已存在');

    try {
      return await this.prisma.$executeRawUnsafe(
      `INSERT INTO sm_xitongkaifa.sys_users(username,password,display_name,code,status) VALUES(?,?,?,?,?)`,
      username, password, displayName, code || null, status
      );
    } catch (e: any) {
      // 兜底：若仍提示列不存在，再次尝试修复一次
      await this.ensureSysUsersSchema();
      return this.prisma.$executeRawUnsafe(
        `INSERT INTO sm_xitongkaifa.sys_users(username,password,display_name,code,status) VALUES(?,?,?,?,?)`,
        username, password, displayName, code || null, status
      );
    }
  }
  updateUser(id: number, u: { display_name?: string; status?: number; password?: string; code?: string }) {
    const sets: string[] = []; const vals: any[] = [];
    if (u.display_name !== undefined) { sets.push('display_name=?'); vals.push(u.display_name); }
    if (u.status !== undefined) { sets.push('status=?'); vals.push(u.status); }
    if (u.password !== undefined) { sets.push('password=?'); vals.push(u.password); }
    if (u.code !== undefined) { sets.push('code=?'); vals.push(u.code); }
    if (!sets.length) return Promise.resolve(0);
    vals.push(id);
    return this.prisma.$executeRawUnsafe(`UPDATE sm_xitongkaifa.sys_users SET ${sets.join(',')} WHERE id=?`, ...vals);
  }
  deleteUser(id: number) { return this.prisma.$executeRawUnsafe(`DELETE FROM sm_xitongkaifa.sys_users WHERE id=?`, id); }
  setUserRoles(userId: number, roleIds: number[]) {
    return this.prisma.$transaction([
      this.prisma.$executeRawUnsafe(`DELETE FROM sm_xitongkaifa.sys_user_roles WHERE user_id=?`, userId),
      this.prisma.$executeRawUnsafe(`INSERT INTO sm_xitongkaifa.sys_user_roles(user_id,role_id) VALUES ${roleIds.map(()=>'(?,?)').join(',')}`,
        ...roleIds.flatMap(rid => [userId, rid]))
    ]);
  }

  // 查询用户已分配的角色ID集合（用于前端展示与预勾选）
  async getUserRoleIds(userId: number) {
    const rows: any[] = await this.prisma.$queryRawUnsafe(`SELECT role_id FROM sm_xitongkaifa.sys_user_roles WHERE user_id=?`, userId);
    return rows.map(r => Number(r.role_id));
  }

  // 查询用户全部权限（用于前端菜单授权）
  async getUserPermissions(userId: number) {
    const rows: any[] = await this.prisma.$queryRawUnsafe(`
      SELECT p.* FROM sm_xitongkaifa.sys_permissions p
      JOIN sm_xitongkaifa.sys_role_permissions rp ON rp.permission_id = p.id
      JOIN sm_xitongkaifa.sys_user_roles ur ON ur.role_id = rp.role_id
      WHERE ur.user_id = ?
    `, userId);
    return rows;
  }

  // 登录：简单用户名/密码校验，返回用户基本信息
  // 支持单点登录：同一用户在新设备登录时，旧设备的token会失效
  async login(username: string, password: string, deviceInfo?: string) {
    await this.ensureSysUsersSchema();
    const rows: any[] = await this.prisma.$queryRawUnsafe(`SELECT id, username, display_name, status, password, session_token FROM sm_xitongkaifa.sys_users WHERE username=? LIMIT 1`, username || '');
    if (!rows.length) throw new BadRequestException('用户不存在');
    const u = rows[0];
    if (String(u.password || '') !== String(password || '')) throw new BadRequestException('密码错误');
    if (Number(u.status) !== 1) throw new BadRequestException('账号已禁用');
    
    // 生成新token
    const token = randomBytes(24).toString('hex');
    const loginTime = new Date();
    const device = deviceInfo || 'unknown';
    
    // 更新用户的session_token (单点登录：覆盖旧token)
    await this.prisma.$executeRawUnsafe(
      `UPDATE sm_xitongkaifa.sys_users SET session_token=?, last_login_time=?, last_login_device=? WHERE id=?`, 
      token, 
      loginTime,
      device,
      Number(u.id)
    );
    
    // 记录登录历史
    try {
      await this.prisma.$executeRawUnsafe(
        `INSERT INTO sm_xitongkaifa.login_records (user_id, username, device_info, login_time, token) VALUES (?, ?, ?, ?, ?)`,
        Number(u.id),
        u.username,
        device,
        loginTime,
        token
      );
    } catch (e) {
      // 如果login_records表不存在，忽略错误
      console.log('[AclService] 登录记录表不存在，跳过记录');
    }
    
    return { id: Number(u.id), username: u.username, display_name: u.display_name, token };
  }

  async validateToken(userId: number, token: string) {
    await this.ensureSysUsersSchema();
    const rows: any[] = await this.prisma.$queryRawUnsafe(`SELECT session_token FROM sm_xitongkaifa.sys_users WHERE id=?`, userId);
    if (!rows.length) return false;
    return String(rows[0]?.session_token || '') === String(token || '');
  }

  async logout(userId: number, token: string) {
    if (!(await this.validateToken(userId, token))) return { success: true };
    await this.prisma.$executeRawUnsafe(`UPDATE sm_xitongkaifa.sys_users SET session_token=NULL WHERE id=?`, userId);
    return { success: true };
  }
}


