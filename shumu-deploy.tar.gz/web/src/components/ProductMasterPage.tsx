"use client";

import React, { useEffect, useMemo, useState } from "react";
import {
  Card,
  Space,
  Input,
  Button,
  Table,
  Drawer,
  Tabs,
  Descriptions,
  Form,
  Modal,
  Row,
  Col,
  message,
  Typography,
} from "antd";
import {
  SearchOutlined,
  EditOutlined,
  PlusOutlined,
  SaveOutlined,
} from "@ant-design/icons";
import {
  productMasterApi,
  labelDataApi,
  LabelDataItem,
} from "@/lib/api";

const { Search } = Input;
const { Text } = Typography;

type MasterListItem = {
  spuCode: string;
  productName: string;
  spec: string;
  skuCode: string;
  productCode: string;
  pickingStandard?: string | null;
};

export default function ProductMasterPage() {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<MasterListItem[]>([]);
  const [sku, setSku] = useState("");
  const [q, setQ] = useState("");

  // 编辑抽屉
  const [open, setOpen] = useState(false);
  const [currentSku, setCurrentSku] = useState<string>("");
  const [masterDetail, setMasterDetail] = useState<Record<string, any> | null>(null);
  const [labelList, setLabelList] = useState<LabelDataItem[]>([]);
  const [labelColumns, setLabelColumns] = useState<{ name: string; type?: string }[]>([]);
  const [editLabelModalOpen, setEditLabelModalOpen] = useState(false);
  const [labelForm] = Form.useForm();

  const load = async (params?: { sku?: string; q?: string }) => {
    setLoading(true);
    try {
      const list = await productMasterApi.list({ q: params?.q, limit: 500 });
      let final = list;
      if (params?.sku) {
        final = list.filter((i) => i.skuCode.includes(params.sku!));
      }
      setData(final);
    } finally {
      setLoading(false);
    }
  };

  const openDrawer = async (row: MasterListItem) => {
    setCurrentSku(row.skuCode);
    setOpen(true);
    // 载入左侧主档全部字段
    const detail = await productMasterApi.detail(row.skuCode);
    setMasterDetail(detail || {});
    // 标签列 & 列表（仅与当前 SKU 关联的数据）
    const cols = await labelDataApi.columns();
    setLabelColumns(cols || []);
    const labels = await labelDataApi.bySku(row.skuCode);
    // 双重保险：即使服务端返回了多SKU，也仅保留当前SKU
    const filtered = (labels || []).filter((it) => {
      const raw = it.labelRaw || {};
      const skuFromRaw = raw["SKU"] || raw["SKU编码"] || raw["sku"] || it.skuCode;
      return String(skuFromRaw) === String(row.skuCode);
    });
    setLabelList(filtered);
  };

  const showCreateLabel = () => {
    setEditLabelModalOpen(true);
    const initial: Record<string, any> = {};
    // 预填充 SKU
    const skuKey = ["SKU", "SKU编码", "sku"].find((k) => labelColumns.some((c) => c.name === k));
    if (skuKey) initial[skuKey] = currentSku;
    labelForm.setFieldsValue(initial);
  };

  const showEditLabel = (item: LabelDataItem) => {
    setEditLabelModalOpen(true);
    labelForm.setFieldsValue(item.labelRaw);
  };

  const handleSaveLabel = async () => {
    try {
      const values = await labelForm.validateFields();
      // 必填校验：SKU + 供应商名称；且强制以当前抽屉的 SKU 保存
      const skuKey = ["SKU", "SKU编码", "sku"].find((k) => (labelColumns || []).some((c) => c.name === k)) || "SKU";
      values[skuKey] = currentSku; // 强制绑定当前 SKU
      if (!values["供应商名称"]) {
        message.error("供应商名称为必填");
        return;
      }
      await labelDataApi.upsert(String(values[skuKey]), values);
      message.success("保存成功");
      setEditLabelModalOpen(false);
      const labels = await labelDataApi.bySku(currentSku);
      setLabelList(labels || []);
    } catch (_) {}
  };

  useEffect(() => {
    load();
  }, []);

  const columns = [
    { title: "SPU编码", dataIndex: "spuCode", key: "spuCode", width: 180 },
    { title: "商品名称", dataIndex: "productName", key: "productName" },
    { title: "规格", dataIndex: "spec", key: "spec", width: 160 },
    { title: "SKU编码", dataIndex: "skuCode", key: "skuCode", width: 180 },
    { title: "商品条码", dataIndex: "productCode", key: "productCode", width: 220 },
    { title: "拣货标准", dataIndex: "pickingStandard", key: "pickingStandard", width: 180 },
    {
      title: "操作",
      key: "action",
      width: 120,
      render: (_: any, record: MasterListItem) => (
        <Button type="link" icon={<EditOutlined />} onClick={() => openDrawer(record)}>
          编辑
        </Button>
      ),
    },
  ];

  const labelTableCols = useMemo(() => {
    const fixedCols = [
      { title: "SKU", dataIndex: ["labelRaw", "SKU"], key: "sku" },
      { title: "供应商名称", dataIndex: ["labelRaw", "供应商名称"], key: "vendor" },
    ];
    const dynamicCols = (labelColumns || [])
      .filter(
        (c) => c.name !== "SKU" && c.name !== "SKU编码" && c.name !== "sku" && c.name !== "供应商名称"
      )
      .map((c) => ({ title: c.name, dataIndex: ["labelRaw", c.name], key: c.name, ellipsis: true }));
    return [
      ...fixedCols,
      ...dynamicCols,
      {
        title: "操作",
        key: "op",
        width: 160,
        render: (_: any, r: LabelDataItem) => (
          <Space>
            <Button type="link" onClick={() => showEditLabel(r)}>编辑</Button>
            <Button
              type="link"
              danger
              onClick={async () => {
                const supplier = r.labelRaw?.["供应商名称"];
                if (!supplier) { message.error('缺少供应商名称'); return; }
                await labelDataApi.remove(currentSku, String(supplier));
                message.success('已删除');
                const labels = await labelDataApi.bySku(currentSku);
                const filtered = (labels || []).filter((it) => {
                  const raw = it.labelRaw || {};
                  const skuFromRaw = raw["SKU"] || raw["SKU编码"] || raw["sku"] || it.skuCode;
                  return String(skuFromRaw) === String(currentSku);
                });
                setLabelList(filtered);
              }}
            >删除</Button>
          </Space>
        ),
      },
    ];
  }, [labelColumns, currentSku]);

  // 渲染前再次按 currentSku 过滤（防御性）
  const labelDataSource = useMemo(() => {
    return (labelList || []).filter((it) => {
      const raw = it.labelRaw || {};
      const skuFromRaw = raw["SKU"] || raw["SKU编码"] || raw["sku"] || it.skuCode;
      return String(skuFromRaw) === String(currentSku);
    });
  }, [labelList, currentSku]);

  const headerInfo = useMemo(() => {
    const name = (masterDetail as any)?.["商品名称"] || "";
    const spec = (masterDetail as any)?.["规格"] || "";
    return (
      <Space size={24}>
        <Text>SKU编号：{currentSku}</Text>
        <Text>商品名称：{name}</Text>
        <Text>规格：{spec}</Text>
      </Space>
    );
  }, [masterDetail, currentSku]);

  return (
    <div style={{ padding: 24 }}>
      <Card
        title="商品资料"
        extra={
          <Space>
            <Search
              placeholder="SKU 精确搜索"
              allowClear
              enterButton={<SearchOutlined />}
              value={sku}
              onChange={(e) => setSku(e.target.value)}
              onSearch={(v) => load({ sku: v.trim(), q })}
              style={{ width: 220 }}
            />
            <Search
              placeholder="关键字搜索（SPU/名称/SKU/条码）"
              allowClear
              enterButton={<SearchOutlined />}
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onSearch={(v) => load({ sku, q: v.trim() })}
              style={{ width: 320 }}
            />
            <Button onClick={() => { setSku(""); setQ(""); load(); }}>重置</Button>
          </Space>
        }
      >
        <Table
          columns={columns}
          dataSource={data}
          rowKey={(r) => r.skuCode}
          loading={loading}
          pagination={{ pageSize: 20, showSizeChanger: true }}
        />
      </Card>

      <Drawer
        title={headerInfo}
        open={open}
        onClose={() => setOpen(false)}
        width={1000}
      >
        <Tabs
          items={[
            {
              key: "master",
              label: "主档信息",
              children: (
                <Descriptions
                  bordered
                  size="small"
                  column={2}
                  items={Object.keys(masterDetail || {}).map((k) => ({
                    key: k,
                    label: k,
                    children: String((masterDetail as any)?.[k] ?? ""),
                  }))}
                />
              ),
            },
            {
              key: "labels",
              label: (
                <Space>
                  <span>标签补充信息</span>
                  <Button size="small" icon={<PlusOutlined />} onClick={showCreateLabel}>
                    新增
                  </Button>
                </Space>
              ),
              children: (
                <Table
                  columns={labelTableCols}
                  dataSource={labelDataSource}
                  rowKey={(r) => r.skuCode + (r.labelRaw?.["供应商名称"] || "")}
                  size="small"
                  pagination={false}
                />
              ),
            },
          ]}
        />
      </Drawer>

      <Modal
        title="编辑标签资料"
        open={editLabelModalOpen}
        onCancel={() => setEditLabelModalOpen(false)}
        onOk={handleSaveLabel}
        okText={<Space><SaveOutlined />保存</Space>}
      >
        <Form form={labelForm} layout="vertical">
          <Row gutter={12}>
            {(labelColumns || []).map((c) => {
              const max: Record<string, number> = {
                'SKU': 50,
                '供应商名称': 50,
                '抬头信息': 15,
                '产品规格': 15,
                '执行标准': 30,
                '产品名称': 13,
                '厂家名称': 26,
                '地址信息': 26,
                '材质': 13,
                '其他信息': 12,
              };
              const maxLen = max[c.name] || undefined;
              return (
                <Col span={12} key={c.name}>
                  <Form.Item
                    name={c.name}
                    label={c.name}
                  >
                    <Input maxLength={maxLen} showCount={!!maxLen} />
                  </Form.Item>
                </Col>
              );
            })}
          </Row>
        </Form>
      </Modal>
    </div>
  );
}







