"use client";

import RedirectPage from '../redirect';

export default function PurchasePage() {
  return <RedirectPage targetPath="/home/purchase" />;
}





