"use client";

import RedirectPage from '../redirect';

export default function SupplierManagementPage() {
  return <RedirectPage targetPath="/home/supplier-management" />;
}