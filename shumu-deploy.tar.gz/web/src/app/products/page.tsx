"use client";

import RedirectPage from '../redirect';

export default function ProductsPage() {
  return <RedirectPage targetPath="/home/products" />;
}