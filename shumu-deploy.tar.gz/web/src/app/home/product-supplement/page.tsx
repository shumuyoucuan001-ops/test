"use client";

import ProductSupplementPage from '../../../components/ProductSupplementPage';
import PermissionGuard from '../../../components/PermissionGuard';

export default function ProductSupplementRoute() {
  return (
    <PermissionGuard requiredPath="/home/product-supplement">
      <ProductSupplementPage />
    </PermissionGuard>
  );
}
