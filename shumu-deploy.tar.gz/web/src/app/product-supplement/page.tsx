"use client";

import RedirectPage from '../redirect';

export default function ProductSupplementPage() {
  return <RedirectPage targetPath="/home/product-supplement" />;
}