"use client";

import RedirectPage from '../redirect';

export default function TemplatesPage() {
  return <RedirectPage targetPath="/home/templates" />;
}