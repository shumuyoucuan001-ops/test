"use client";

import RedirectPage from '../../redirect';

export default function AdminPermissionsPage() {
  return <RedirectPage targetPath="/home/admin-permissions" />;
}