"use client";

import RedirectPage from '../../redirect';

export default function AdminRolesPage() {
  return <RedirectPage targetPath="/home/admin-roles" />;
}