"use client";

import RedirectPage from '../../redirect';

export default function AdminUsersPage() {
  return <RedirectPage targetPath="/home/admin-users" />;
}