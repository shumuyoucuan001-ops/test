"use client";

import React, { useState } from "react";
import { Card, Button, Space, message, Form, Input } from "antd";
import { aclApi } from "@/lib/api";

export default function LoginPage() {
  const [loading, setLoading] = useState(false);
  const [form] = Form.useForm();
  // React 19 + antd v5: 使用 useMessage，避免静态 message 触发兼容告警
  const [msgApi, contextHolder] = message.useMessage();
  const onSubmit = async () => {
    try {
      const v = await form.validateFields();
      setLoading(true);
      const u = await aclApi.login(v.username, v.password);
      localStorage.setItem('userId', String(u.id));
      localStorage.setItem('displayName', u.display_name || '');
      localStorage.setItem('sessionToken', u.token || '');
      msgApi.success('登录成功');
      location.href = '/home';
    } catch (e: any) {
      const msg = e?.response?.data?.message || e?.message || '登录失败';
      msgApi.error(msg);
    } finally {
      setLoading(false);
    }
  };
  return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100vh' }}>
      {contextHolder}
      <Card title="登录到术木优选">
        <Form layout="vertical" form={form} onFinish={onSubmit} style={{ width: 320 }}>
          <Form.Item name="username" label="用户名" rules={[{required:true}]}>
            <Input autoFocus placeholder="用户名" />
          </Form.Item>
          <Form.Item name="password" label="密码" rules={[{required:true}]}>
            <Input.Password placeholder="密码" />
          </Form.Item>
          <Space>
            <Button type="primary" htmlType="submit" loading={loading}>登录</Button>
          </Space>
        </Form>
      </Card>
    </div>
  );
}


