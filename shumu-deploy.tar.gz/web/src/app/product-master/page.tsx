"use client";

import RedirectPage from '../redirect';

export default function ProductMasterPage() {
  return <RedirectPage targetPath="/home/products" />;
}