# 🚀 宝塔面板 - 使用 Git 部署新后端服务

## 📋 **部署方案**

创建一个新的后端服务 `sm-api-v2`，使用 Git 自动部署，与旧服务共存。

### **配置对比**

| 项目     | 旧后端 (sm-api)           | 新后端 (sm-api-v2)            |
| -------- | ------------------------- | ----------------------------- |
| 端口     | 4000                      | **5000**                      |
| 部署方式 | 手动上传                  | **Git 自动部署**              |
| 代码版本 | 旧版本                    | **最新 develop 分支**         |
| API 地址 | api.shuzhishanmu.com:4000 | **api.shuzhishanmu.com:5000** |
| 状态     | 保留运行                  | **新建**                      |

---

## 📝 **步骤 1: 在宝塔面板创建新 Node 项目**

### 1.1 登录宝塔面板

- 访问: http://121.43.139.147:8888
- 登录您的宝塔账号

### 1.2 创建新的 Node 项目

1. 点击左侧 **"Node 项目"**
2. 点击 **"添加项目"**
3. 填写项目信息：

```
项目名称: sm-api-v2
运行目录: /www/wwwroot/sm-api-v2
端口: 5000
启动文件: dist/main.js
启动命令: node
运行用户: www

✅ 勾选: 开机自启动
✅ 勾选: 自动重启
```

4. 点击 **"提交"**

---

## 📝 **步骤 2: 配置 Git 部署**

### 2.1 在宝塔面板配置 Git

1. 在 Node 项目列表中找到 **sm-api-v2**
2. 点击 **"设置"**
3. 找到 **"Git 部署"** 选项卡
4. 填写 Git 仓库信息：

```
Git地址: https://github.com/xuxiang6/shumu.git
分支: develop
部署目录: /www/wwwroot/sm-api-v2
```

5. 点击 **"拉取"** 按钮

### 2.2 设置项目目录

由于我们的后端代码在 `server/` 子目录中，需要调整：

**方法 A: 在宝塔终端执行**（推荐）

```bash
# 进入项目目录
cd /www/wwwroot/sm-api-v2

# 将server目录的内容移到根目录
mv server/* .
mv server/.* . 2>/dev/null || true
rmdir server

# 安装依赖
npm install

# 构建项目
npm run build
```

**方法 B: 修改宝塔项目配置**

1. 项目设置 → 运行目录
2. 改为: `/www/wwwroot/sm-api-v2/server`
3. 启动文件: `dist/main.js`

---

## 📝 **步骤 3: 配置环境和启动**

### 3.1 创建环境文件（如果需要）

在宝塔终端执行：

```bash
cd /www/wwwroot/sm-api-v2

# 创建.env文件（如果需要）
cat > .env << 'EOF'
PORT=5000
NODE_ENV=production
DATABASE_URL="file:./prisma/dev.db"
EOF
```

### 3.2 初始化数据库

```bash
cd /www/wwwroot/sm-api-v2

# 生成Prisma Client
npx prisma generate

# 运行数据库迁移
npx prisma migrate deploy
```

### 3.3 启动项目

在宝塔面板中：

1. 找到 **sm-api-v2** 项目
2. 点击 **"启动"** 按钮

---

## 📝 **步骤 4: 配置防火墙和安全组**

### 4.1 配置阿里云安全组

1. 访问: https://ecs.console.aliyun.com/
2. 找到 ECS 实例 (121.43.139.147)
3. 点击 "安全组" → "配置规则"
4. 添加规则：
   ```
   协议类型: 自定义TCP
   端口范围: 5000/5000
   授权对象: 0.0.0.0/0
   描述: sm-api-v2新后端服务
   ```

### 4.2 配置宝塔防火墙

1. 在宝塔面板左侧点击 **"安全"**
2. 点击 **"添加规则"**
3. 填写：
   ```
   端口: 5000
   说明: sm-api-v2新后端服务
   ```
4. 点击 **"放行"**

---

## 🧪 **步骤 5: 测试新后端 API**

### 从 Mac 本地测试

```bash
# 1. 测试健康检查
curl http://121.43.139.147:5000/health

# 2. 测试版本检查
curl "http://121.43.139.147:5000/version/check?current=25.10.03.04"

# 3. 测试模板生成
curl -X POST http://121.43.139.147:5000/template/generate-tspl \
  -H "Content-Type: application/json" \
  -d '{"templateId":"default","data":{"sku":"TEST123"},"copies":1}'
```

**预期结果：**

- `/health` 返回: `{"status":"ok"}`
- `/version/check` 返回版本信息
- `/template/generate-tspl` 返回 TSPL 命令

---

## 📝 **步骤 6: 使用域名访问（可选）**

### 方案 A: 使用不同端口

```
旧后端: http://api.shuzhishanmu.com:4000
新后端: http://api.shuzhishanmu.com:5000
```

### 方案 B: 使用不同子域名（推荐）

1. 配置 DNS A 记录：

   ```
   主机记录: api-v2
   记录类型: A
   记录值: 121.43.139.147
   ```

2. 访问地址：
   ```
   旧后端: http://api.shuzhishanmu.com:4000
   新后端: http://api-v2.shuzhishanmu.com:5000
   ```

### 方案 C: 配置 Nginx 反向代理（最专业）

在宝塔面板配置：

```nginx
# 新后端使用5000端口，不带端口号访问
location /api/v2/ {
    proxy_pass http://127.0.0.1:5000/;
}

# 旧后端保持不变
location /api/ {
    proxy_pass http://127.0.0.1:4000/;
}
```

---

## 🎯 **后续操作**

### 1. 移动应用配置更新

修改 `SmLabelAppRN/src/api.ts`:

**方案 A: 直接使用新端口**

```typescript
const API_BASE_URL = "http://api.shuzhishanmu.com:5000";
```

**方案 B: 使用新子域名**

```typescript
const API_BASE_URL = "http://api-v2.shuzhishanmu.com:5000";
```

### 2. 测试完成后

如果新后端测试完全正常：

1. ✅ 保留旧后端（sm-api）作为备份
2. ✅ 新应用版本全部使用新后端（sm-api-v2）
3. ✅ 观察一段时间后，可以停止旧后端

---

## 🔧 **常用运维命令**

### 查看项目日志

```bash
cd /www/wwwroot/sm-api-v2
pm2 logs sm-api-v2
```

### 重启项目

```bash
pm2 restart sm-api-v2
```

### 更新代码

```bash
cd /www/wwwroot/sm-api-v2
git pull origin develop
npm install
npm run build
pm2 restart sm-api-v2
```

### 查看项目状态

```bash
pm2 status
```

---

## 📌 **注意事项**

1. **数据库独立**

   - 新后端会有自己的数据库文件
   - 如需迁移数据，需要从旧后端复制数据库文件

2. **端口冲突**

   - 确保 5000 端口未被占用
   - 可以用 `netstat -tulpn | grep 5000` 检查

3. **Git 部署优势**
   - 后续更新只需 `git pull` + `npm run build` + `pm2 restart`
   - 代码版本可追溯
   - 支持回滚

---

## 🚨 **故障排查**

### 问题 1: Git 拉取失败

```bash
# 检查网络
ping github.com

# 使用SSH密钥（如果配置了）
cd /www/wwwroot/sm-api-v2
git remote set-url origin git@github.com:xuxiang6/shumu.git
```

### 问题 2: npm install 失败

```bash
# 切换淘宝镜像
npm config set registry https://registry.npmmirror.com
npm install
```

### 问题 3: 启动失败

```bash
# 查看详细日志
pm2 logs sm-api-v2 --lines 100

# 检查构建是否成功
ls -la /www/wwwroot/sm-api-v2/dist/
```

---

## ✅ **部署检查清单**

- [ ] 在宝塔面板创建 sm-api-v2 项目
- [ ] 配置 Git 仓库并拉取代码
- [ ] 调整目录结构（如果需要）
- [ ] 安装依赖 `npm install`
- [ ] 构建项目 `npm run build`
- [ ] 初始化数据库
- [ ] 配置阿里云安全组（5000 端口）
- [ ] 配置宝塔防火墙（5000 端口）
- [ ] 启动项目
- [ ] 测试 API 接口
- [ ] 修改移动应用 API 地址
- [ ] 重新构建 APK 测试

---

**完成后告诉我结果，我会帮您验证和测试！** 🚀
